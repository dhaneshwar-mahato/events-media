<!-- Footer -->
<footer>
    <p style="text-align: center;">&copy; <?php echo date("Y"); ?> Event Service Booking. All rights reserved.</p>
</footer>

</body>
</html>
